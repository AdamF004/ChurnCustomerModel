import xgboost as xgb
from sklearn.metrics import accuracy_score, classification_report

class XGBoostModel:
    def __init__(self, objective="multi:softmax", num_class=3, random_state=42):
        self.model = xgb.XGBClassifier(objective=objective, num_class=num_class, random_state=random_state)
    
    def fit(self, X_train, y_train):
        self.model.fit(X_train, y_train)
    
    def predict(self, X_test):
        return self.model.predict(X_test)
    
    def evaluate(self, X_test, y_test):
        y_pred = self.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)
        print("Accuracy:", accuracy)
        print('\nClassification Report:\n')
        print(classification_report(y_test, y_pred, target_names=['0','1']))


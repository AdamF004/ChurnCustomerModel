import streamlit as st
import joblib
import numpy as np

file_path = r'C:\Users\Adam Ferdinand\OneDrive\Documents\Kampus Binus\Model Deployment\UTS\XGB_class.pkl'
model = joblib.load(file_path) 

def main():
    st.title("XGBoost Model Deployment of Churn")

    CreditScore = st.slider('CreditScore', min_value=350.0, max_value=1000.0, value=350.0)
    Geography = st.slider('Geography(France: 0, Spain: 2, Germany: 1)', min_value=0.0, max_value=2.0, value=0.0)
    Gender = st.slider('Gender (1: Male, 0: Female)', min_value=0.0, max_value=1.0, value=0.0)
    Age = st.slider('Age' , min_value=18.0, max_value=100.0, value=18.0)
    Tenure = st.slider('Tenure', min_value=0.0, max_value=10.0, value=0.0)
    Balance = st.slider('Balance', min_value=0.0, max_value=250000.0, value=0.0)
    NumofProducts = st.slider('NumOfProducts', min_value=1.0, max_value=5.0, value=1.0)
    HasCrCard = st.slider('HasCrCard', min_value=0.0, max_value=1.0, value=0.0)
    IsActiveMember = st.slider('IsActiveMember', min_value=0.0, max_value=1.0, value=0.0)
    EstimatedSalary = st.slider('EstimatedSalary', min_value=11.580, max_value=200000.0, value=11.580)

    if st.button('Make Prediction'):
        features = [CreditScore, Geography, Gender, Age, Tenure, Balance, NumofProducts, HasCrCard, IsActiveMember, EstimatedSalary]
        result = make_prediction(features)
        st.success(f'The prediction is: {result}')

def make_prediction(features):
    input_array = np.array(features).reshape(1, -1)
    prediction = model.predict(input_array)
    return prediction[0]

if __name__ == '__main__':
    main()